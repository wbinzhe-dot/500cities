library(dplyr)
library(stringr)
library(fst)
library(data.table)
library(sf)
library(patchwork)
library(ggplot2)



############### Figure 5. Chicago Accessibility Maps ###############
{
  
  # city parameters
  coef <- fread("coef_500cities_260326_controls.csv")
  chicago_coef <- coef[coef$PLACENAME == "Chicago, IL",]
  
  
  # cbg shapefiles
  cbgs <- read_sf('replication_folder/supplementary_data/CBGs/CBGs_500cities_n72729B.shp')
  st_crs(cbgs)
  cbg_chicago  <- cbgs[cbgs$ST == "IL" & cbgs$NAME_2 == "Chicago",]
  plot(cbg_chicago$geometry)
  jt_od_devices_plot <- jt_od_devices
  jt_od_devices_plot <- data.table(jt_od_devices_plot)
  jt_od_devices_plot <- jt_od_devices_plot[jt_od_devices_plot$o_PlACENAME == "Chicago, IL",]
  dim(jt_od_devices_plot)
  
 
  # rail station shapefiles
  rail <- read_sf('replication_folder/supplementary_data/CTA_RailStations.kml')
  des_list <- XML::readHTMLTable(rail$Description)[c(seq(1, 288, 2))]
  des <- lapply(des_list, function(x){
    des_i <- data.table(x[1,1])
    return(des_i)
  })
  des_dt <- rbindlist(des)
  rail$Description <- des_dt$V1
  rail$station_id <- str_sub(rail$Description, -5, -1)
  rail$route <- str_extract(rail$Description, "LINES (.*) ADDRESS") %>% str_remove_all("LINES | ADDRESS")
  table(rail$route )
  plot(rail$geometry)
  st_crs(rail)
  
  # rail station in cbg
  rail <- st_transform(rail, crs = st_crs(cbgs))
  cbg_order <- st_within(rail$geometry, cbg_chicago)
  rail$in_cbg <- cbg_chicago$GEOID[as.numeric(cbg_order)]
  rail <- rail[!is.na(rail$in_cbg),]
  
  cbg_chicago$transit_cbg <- cbg_chicago$GEOID %in% rail$in_cbg
  table(cbg_chicago$transit_cbg)
  chicago_transit_cbg <- cbg_chicago[cbg_chicago$transit_cbg == 1, ]
  
  ggplot() +
    geom_sf(data = cbg_chicago, aes(fill = transit_cbg), color = "white", alpha = .5)+
    geom_sf(data = rail, size = .25) +
    geom_sf_label(data = rail, aes(label = Name), label.size = 0, alpha = 0, size = 3) +
    theme_void()
  
  # nearest station cbg
  transit_cbg_order <- st_nearest_feature(cbg_chicago, chicago_transit_cbg)
  table(transit_cbg_order)
  cbg_chicago$near_cbg_transit <- chicago_transit_cbg$GEOID[as.numeric(transit_cbg_order)]
  
  # select od pairs
  cbg_chicago$od_pair <- paste0(cbg_chicago$GEOID, ",", cbg_chicago$near_cbg_transit)
  dim(cbg_chicago)
  jt_od_devices_plot$od_pair <- paste0(jt_od_devices_plot$o_cbg, ",", jt_od_devices_plot$d_cbg)
  dim(jt_od_devices_plot)
  jt_od_devices_plot_chicago <- jt_od_devices_plot[od_pair %in% cbg_chicago$od_pair]
  dim(jt_od_devices_plot_chicago)
  
  cbg_chicago <- cbg_chicago %>% left_join(jt_od_devices_plot_chicago[, c("time_cost", "edd", "edd_inc", "od_pair")], by = "od_pair")
  chicago_coef
  
  edd_eqv <- 0.5325328/0.06871587
  inc_eqv <- 0.1066859/0.06871587
  
  p1 <- ggplot() +
    geom_sf(data = cbg_chicago[!is.na(cbg_chicago$edd),], aes(fill = (edd*edd_eqv + edd_inc*inc_eqv)/(time_cost + edd*edd_eqv + edd_inc*inc_eqv)), color = "grey30", alpha = .75)+
    geom_sf(data = rail, size = .75, shape = 1) +
    scale_fill_gradient2(low = "cyan3", mid = "white", high = "coral3", midpoint = .33, na.value = "grey80") + 
    labs(fill = "Share", title = "time-equivalent of physical plus social distances" ) + 
    theme_void()+  theme(plot.title = element_text(hjust = 0.5))
  
  p2 <- ggplot() +
    geom_sf(data = cbg_chicago[!is.na(cbg_chicago$edd),], aes(fill = time_cost), color = "grey30", alpha = .75)+
    geom_sf(data = rail, size = .75, shape = 1) +
    scale_fill_gradient2(low = "cyan3", mid = "white", high = "coral3", midpoint = 10) + 
    labs(title = "Physical travel time", fill = "Minutes") + 
    theme_void()+  theme(plot.title = element_text(hjust = 0.5))
 
  p4 <- ggplot() +
    geom_sf(data = cbg_chicago[!is.na(cbg_chicago$edd),], aes(fill = edd*edd_eqv), color = "grey30", alpha = .75)+
    geom_sf(data = rail, size = .75, shape = 1) +
    scale_fill_gradient(low = "white", high = "coral2", limits = c(0, 8)) + 
    labs(fill = "Minutes", title = "race" ) + 
    theme_void()+  theme(plot.title = element_text(hjust = 0.5))
  
  p5 <- ggplot() +
    geom_sf(data = cbg_chicago[!is.na(cbg_chicago$edd),], aes(fill = edd_inc*inc_eqv), color = "grey30", alpha = .75)+
    geom_sf(data = rail, size = .75, shape = 1) +
    scale_fill_gradient(low = "white", high = "coral2", limits = c(0, 2), n.breaks = 3) + 
    labs(fill = "Minutes", title = "income" ) + 
    theme_void()+  theme(plot.title = element_text(hjust = 0.5))
  
  
  (p5|p4)/(p2|p1)
  # ggsave("access_transit_updated.png", width = 9, height = 10)
  
  
  
}