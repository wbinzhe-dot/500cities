# adding attrbitues to cbg pairs
# version: 20241010
library(dplyr)
library(stringr)
library(fst)
library(data.table)
library(sf)
library(patchwork)
library(ggplot2)
library(fixest)
library(msm)
options(scipen=10000)



# setwd('~/Dropbox/Research/0_working_papers/submissions/202503_500cities/PNASNexus/Submission materials')

##################### I. Aggregated to ordered pairs as robustness check #####################
jt_od_devices <- read_fst('replication_folder/modelling_data/jt_od_devices_clean_202609.fst') # 4GB
names(jt_od_devices)

# construct ordered dataset for robustness checks
jt_od_devices_ordered <- data.table(jt_od_devices)
jt_od_devices_ordered$inc_upward <- jt_od_devices_ordered$d_MedianHhIncome > jt_od_devices_ordered$o_MedianHhIncome

jt_od_devices_ordered$inc_od_dif <- (jt_od_devices_ordered$d_MedianHhIncome - jt_od_devices_ordered$o_MedianHhIncome)
hist(jt_od_devices_ordered$inc_od_dif)
jt_od_devices_ordered$Bl_od_dif <- jt_od_devices_ordered$d_PctBlack - jt_od_devices_ordered$o_PctBlack
hist(jt_od_devices_ordered$Bl_od_dif)
jt_od_devices_ordered$Hisp_od_dif <- jt_od_devices_ordered$d_PctHisp - jt_od_devices_ordered$o_PctHisp
hist(jt_od_devices_ordered$Hisp_od_dif)
jt_od_devices_ordered$As_od_dif <- jt_od_devices_ordered$d_PctAsian - jt_od_devices_ordered$o_PctAsian
hist(jt_od_devices_ordered$As_od_dif)

jt_od_devices_ordered <- jt_od_devices_ordered[!str_detect(pair, "80319800001")] # Denver airport obnormally large number, 478 observations
dim(jt_od_devices_ordered)
summary(jt_od_devices_ordered$time_cost)

jt_od_devices_ordered <- jt_od_devices_ordered[,":="(city_obs = .N), list(d_PlACENAME)]
jt_od_devices_ordered$inv_obs <- 1/jt_od_devices_ordered$city_obs

# descriptive scatter plot
{
  # travel time
  hist(jt_od_devices_ordered$time_cost)
  summary(jt_od_devices_ordered$time_cost > 60)
  jt_od_devices_ordered$time_bin <- cut(jt_od_devices_ordered$time_cost, c(seq(-.1, 50, 5), 100))
  table(jt_od_devices_ordered$time_bin)
  
  #check
  check <- jt_od_devices_ordered[time_cost > 50 & o_PlACENAME == "Denver, CO"]
  dim(check)
  summary(check$home_devices)
  table(check$o_PlACENAME)
  
  jt_od_devices_ordered <- jt_od_devices_ordered[!str_detect(o_cbg, "80319800001") & !str_detect(d_cbg, "80319800001") ]
  
  jt_od_devices_ordered_sum <- jt_od_devices_ordered[,.(ave_time = mean(time_cost),
                                                        home_devices = mean(home_devices),
                                                        home_devices_se = sd(home_devices)/sqrt(.N),
                                                        work_devices = mean(work_devices),
                                                        work_devices_se = sd(work_devices)/sqrt(.N),
                                                        obs = .N), list(time_bin)]
  
  
  physical_dist_scatter <- ggplot(jt_od_devices_ordered_sum) +
    geom_point(aes(x = ave_time, y = home_devices, size = obs), shape = 1) +
    geom_errorbar(aes(x = ave_time, ymin = home_devices - 1.96*home_devices_se, ymax = home_devices + 1.96*home_devices_se), alpha = .5, width = .75) +
    labs(x = "average travel time", y = "average device count") + 
    theme_classic()
  
  # black pop share
  jt_od_devices_ordered$Bl_od_dif_bin <- cut(jt_od_devices_ordered$Bl_od_dif, c(-101, seq(-85, 85, 10), 100))
  table(jt_od_devices_ordered$Bl_od_dif_bin)
  
  
  jt_od_devices_ordered_sum <- jt_od_devices_ordered[,.(ave_time = mean(time_cost),
                                                        Bl_od_dif = mean(Bl_od_dif,na.rm = T),
                                                        home_devices = mean(home_devices),
                                                        home_devices_se = sd(home_devices)/sqrt(.N),
                                                        work_devices = mean(work_devices),
                                                        work_devices_se = sd(work_devices)/sqrt(.N),
                                                        obs = .N), list(Bl_od_dif_bin)]
  
  
  Bl_dist_scatter <- ggplot(jt_od_devices_ordered_sum) +
    geom_vline(xintercept = 0, alpha = .35) +
    geom_point(aes(x = Bl_od_dif, y = home_devices, size = obs), shape = 1) +
    geom_errorbar(aes(x = Bl_od_dif, ymin = home_devices - 2*home_devices_se, ymax = home_devices + 2*home_devices_se), alpha = .5) +
    labs(x = "% Black difference (destination - origin)", y = "average device count") + 
    theme_classic()
  
  
  # hisp pop share
  jt_od_devices_ordered$Hisp_od_dif_bin <- cut(jt_od_devices_ordered$Hisp_od_dif, c(-101, seq(-85, 85, 10), 100))
  table(jt_od_devices_ordered$Hisp_od_dif_bin)
  
  
  jt_od_devices_ordered_sum <- jt_od_devices_ordered[,.(ave_time = mean(time_cost),
                                                        Hisp_od_dif = mean(Hisp_od_dif,na.rm = T),
                                                        home_devices = mean(home_devices),
                                                        home_devices_se = sd(home_devices)/sqrt(.N),
                                                        work_devices = mean(work_devices),
                                                        work_devices_se = sd(work_devices)/sqrt(.N),
                                                        obs = .N), list(Hisp_od_dif_bin)]
  
  
  hisp_dist_scatter <- ggplot(jt_od_devices_ordered_sum) +
    geom_vline(xintercept = 0, alpha = .35) +
    geom_point(aes(x = Hisp_od_dif, y = home_devices, size = obs), shape = 1) +
    geom_errorbar(aes(x = Hisp_od_dif, ymin = home_devices - 2*home_devices_se, ymax = home_devices + 2*home_devices_se), alpha = .5) +
    labs(x = "% Hisp difference (destination - origin)", y = "average device count") + 
    theme_classic()
  
  
  # Asian pop share
  jt_od_devices_ordered$As_od_dif_bin <- cut(jt_od_devices_ordered$As_od_dif, c(-101, seq(-85, 85, 10), 100))
  table(jt_od_devices_ordered$As_od_dif_bin)
  
  
  jt_od_devices_ordered_sum <- jt_od_devices_ordered[,.(ave_time = mean(time_cost),
                                                        As_od_dif = mean(As_od_dif,na.rm = T),
                                                        home_devices = mean(home_devices),
                                                        home_devices_se = sd(home_devices)/sqrt(.N),
                                                        work_devices = mean(work_devices),
                                                        work_devices_se = sd(work_devices)/sqrt(.N),
                                                        obs = .N), list(As_od_dif_bin)]
  
  
  as_dist_scatter <- ggplot(jt_od_devices_ordered_sum) +
    geom_vline(xintercept = 0, alpha = .35) +
    geom_point(aes(x = As_od_dif, y = home_devices, size = obs), shape = 1) +
    geom_errorbar(aes(x = As_od_dif, ymin = home_devices - 2*home_devices_se, ymax = home_devices + 2*home_devices_se), alpha = .5) +
    labs(x = "% Asian difference (destination - origin)", y = "average device count") + 
    theme_classic()
  
  jt_od_devices_ordered$inc_do_dif <- (jt_od_devices_ordered$d_MedianHhIncome - jt_od_devices_ordered$o_MedianHhIncome)/1000
  jt_od_devices_ordered$inc_od_dif_bin <- cut(jt_od_devices_ordered$inc_do_dif, c(-250, -180, seq(-135, 135, 30), 180, 250))
  table(jt_od_devices_ordered$inc_od_dif_bin)
  
  
  jt_od_devices_ordered_sum <- jt_od_devices_ordered[,.(ave_time = mean(time_cost),
                                                        inc_od_dif = mean(inc_od_dif,na.rm = T),
                                                        home_devices = mean(home_devices),
                                                        home_devices_se = sd(home_devices)/sqrt(.N),
                                                        work_devices = mean(work_devices),
                                                        work_devices_se = sd(work_devices)/sqrt(.N),
                                                        obs = .N), list(inc_od_dif_bin)]
  
  
  inc_dist_scatter <- ggplot(jt_od_devices_ordered_sum) +
    geom_vline(xintercept = 0, alpha = .35) +
    geom_point(aes(x = inc_od_dif/1000, y = home_devices, size = obs), shape = 1) +
    geom_errorbar(aes(x = inc_od_dif/1000, ymin = home_devices - 2*home_devices_se, ymax = home_devices + 2*home_devices_se), alpha = .5) +
    labs(x = "Med HH income diff in 1000  (destination - origin)", y = "average device count") + 
    theme_classic()
  
  # Figure S2
  (inc_dist_scatter|Bl_dist_scatter)/(hisp_dist_scatter|as_dist_scatter)
  # ggsave("ordered_scatter_all_cities.png", width = 12, height = 8)
  
  
}

# pooled analysis in Supplementary Table S3
lm <- feols(log(home_devices) ~ time_cost  + edd + edd_inc + log(o_TotalPax) + log(d_TotalPax) + log(o_cbg_jobs)+ log(d_cbg_jobs) + log(o_cbg_amenity) + log(d_cbg_amenity)|d_PlACENAME, data = jt_od_devices_ordered) 
lm.incx <- feols(log(home_devices) ~ time_cost  + edd + edd_inc*inc_upward + log(o_TotalPax) + log(d_TotalPax) + log(o_cbg_jobs)+ log(d_cbg_jobs) + log(o_cbg_amenity) + log(d_cbg_amenity)|d_PlACENAME, data = jt_od_devices_ordered) 
lm.incx.w <- feols(log(home_devices) ~ time_cost  + edd + edd_inc*inc_upward + log(o_TotalPax) + log(d_TotalPax) + log(o_cbg_jobs)+ log(d_cbg_jobs) + log(o_cbg_amenity) + log(d_cbg_amenity)|d_PlACENAME, data = jt_od_devices_ordered, weights = jt_od_devices_ordered$inv_obs) 
etable(lm, lm.incx, 
       digits = 3,
       # tex = T,
       se.below = T,
       order = c("travel time",  "race dist", "income dist", "inc_upward",
                 "Hispanic dist","Black dist","Asian dist"), 
       dict = c("edd" = "race dist",
                "edd_bl" = "Black dist",
                "edd_as" = "Asian dist",
                "edd_hs" = "Hispanic dist",
                "edd_inc" = "income dist",
                "time_cost" = "travel time",
                "PLACENAME" = "City FE"))





# origin & destinition fixed effects
fm <- formula(log(home_devices) ~ time_cost  + edd +  edd_inc + df_renter + df_car + df_female|d_cbg + d_cbg) 
local_est <- function(fip){
  local_data <- jt_od_devices_ordered[d_PlACENAME == fip,][!is.na(edd_inc)][time_cost < 120]
  if(nrow(local_data) > 6){
    l2.lc <- feols(fm, data = local_data)
    ct <- l2.lc$coeftable
    ct <- ct[str_detect(rownames(ct), "time_cost|edd$|edd_inc"), 1:2]
    cdt <- data.frame(unlist(ct)  %>% t())
    names(cdt) <- c("coef_time", "coef_edd", "coef_inc", "se_time", "se_edd", "se_inc")
    cdt$edd_time_ratio <- cdt$coef_edd/cdt$coef_time
    cdt$inc_time_ratio <- cdt$coef_inc/cdt$coef_time
    
    edd_time_se <- deltamethod(~x2/x1, l2.lc$coefficients[1:2], vcov(l2.lc)[1:2,1:2],ses = T)
    inc_time_se <- deltamethod(~x2/x1, l2.lc$coefficients[c(1,3)], vcov(l2.lc)[c(1,3),c(1,3)],ses = T)
    
    cdt <- cbind("PLACENAME" = fip, 
                 "obs" = l2.lc$nobs,
                 "cbgs" = length(unique(local_data$d_cbg)), 
                 cdt,
                 "edd_time_se" = edd_time_se,
                 "inc_time_se" = inc_time_se)
    print(fip)
    return(cdt)
  }else{
    print("******wrong******")
    cdt <- {}
  }
  
}

ct_list <- lapply(unique(jt_od_devices_ordered$d_PlACENAME), local_est)
ct_local <- rbindlist(ct_list)
ct_local$df <- ct_local$obs - ct_local$cbgs*2
summary(ct_local) # 498 cities

hist(ct_local$edd_time_ratio[ct_local$edd_time_ratio<1000], breaks = 1000)

(ct_local[ct_local$edd_time_ratio>150])

hist(ct_local$edd_time_ratio/ct_local$edd_time_se)
hist(ct_local$inc_time_ratio/ct_local$inc_time_se)

plotdata_oder <- ct_local[ct_local$edd_time_ratio<150] %>% arrange(coef_time)
plotdata_oder$PLACENAME <- factor(plotdata_oder$PLACENAME, levels = plotdata_oder$PLACENAME)
rank0 <- ggplot(plotdata_oder) +
  geom_vline(xintercept = 0) + 
  geom_vline(xintercept = mean(plotdata_oder$coef_time), color = "grey50", linetype = "dashed") + 
  geom_vline(xintercept = median(plotdata_oder$coef_time), color = "grey50", linetype = "dashed") + 
  # geom_vline(xintercept = round(mean(ct_local$coef_time), 2)) +
  geom_point(aes(y = PLACENAME, x = coef_time), size = .05, color = "grey50") +
  geom_errorbarh(aes(y = PLACENAME, xmin = coef_time - 1.96*se_time, xmax = coef_time+ 1.96*se_time), alpha = .3, color = "grey50") +
  labs(x = "time coef", y = NULL, title = "(1) time coef")+
  geom_label(data = plotdata_oder[1:3,], aes(x = mean(plotdata_oder$coef_time), y = 30), label = paste0("mean = ", round(mean(plotdata_oder$coef_time), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  geom_label(data = plotdata_oder[1:3,], aes(x = median(plotdata_oder$coef_time), y = 60), label = paste0("median = ", round(median(plotdata_oder$coef_time), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  # lims(x = c(-.6, 0)) + 
  theme_classic() + 
  theme(axis.text.y=element_blank(), 
        axis.ticks.y=element_blank()) 

plotdata_oder <- ct_local[ct_local$edd_time_ratio<150] %>% arrange(edd_time_ratio)
plotdata_oder$PLACENAME <- factor(plotdata_oder$PLACENAME, levels = plotdata_oder$PLACENAME)
rank1 <- ggplot(plotdata_oder) +
  geom_vline(xintercept = 0) + 
  geom_vline(xintercept = mean(plotdata_oder$edd_time_ratio), color = "coral2", linetype = "dashed") + 
  geom_vline(xintercept = median(plotdata_oder$edd_time_ratio), color = "coral2", linetype = "dashed") + 
  # geom_vline(xintercept = round(mean(ct_local$coef_time), 2)) +
  geom_point(aes(y = PLACENAME, x = edd_time_ratio), size = .05, color = "coral2") +
  geom_errorbarh(aes(y = PLACENAME, xmin = edd_time_ratio - 1.96*edd_time_se, xmax = edd_time_ratio+ 1.96*edd_time_se), alpha = .3, color = "coral2") +
  labs(x = "time-equivalent (minute)", y = NULL, title = "(2) race coef/time coef")+
  geom_label(data = plotdata_oder[1:3,], aes(x = mean(plotdata_oder$edd_time_ratio), y = 30), label = paste0("mean = ", round(mean(plotdata_oder$edd_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  geom_label(data = plotdata_oder[1:3,], aes(x = median(plotdata_oder$edd_time_ratio), y = 60), label = paste0("median = ", round(median(plotdata_oder$edd_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  # lims(x = c(-.6, 0)) + 
  theme_classic() + 
  theme(axis.text.y=element_blank(), 
        axis.ticks.y=element_blank()) 



plotdata_oder <- ct_local[ct_local$edd_time_ratio<150] %>% arrange(inc_time_ratio)
plotdata_oder$PLACENAME <- factor(plotdata_oder$PLACENAME, levels = plotdata_oder$PLACENAME)


rank2 <- ggplot(plotdata_oder) +
  geom_vline(xintercept = 0) + 
  geom_vline(xintercept = mean(plotdata_oder$inc_time_ratio), color = "coral2", linetype = "dashed") +
  geom_vline(xintercept = median(plotdata_oder$inc_time_ratio), color = "coral2", linetype = "dashed") + 
  # geom_vline(xintercept = round(mean(ct_local$coef_time), 2)) +
  geom_point(aes(y = PLACENAME, x = inc_time_ratio), size = .05, color = "coral2") +
  geom_errorbarh(aes(y = PLACENAME, xmin = inc_time_ratio - 1.96*inc_time_se, xmax = inc_time_ratio+ 1.96*inc_time_se), alpha = .3, color = "coral2") +
  labs(x = "time-equivalent (minute)", y = NULL, title = "(3) income coef/time coef")+
  geom_label(data = plotdata_oder[1:3,], aes(x = mean(plotdata_oder$inc_time_ratio), y = 30), label = paste0("mean = ", round(mean(plotdata_oder$inc_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  geom_label(data = plotdata_oder[1:3,], aes(x = median(plotdata_oder$inc_time_ratio), y = 60), label = paste0("median = ", round(median(plotdata_oder$inc_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
  # lims(x = c(-.6, 0)) + 
  theme_classic() + 
  theme(axis.text.y=element_blank(), 
        axis.ticks.y=element_blank()) 

# Figure S6
rank0|rank1|rank2
# ggsave("ranking_fe.png", width = 10, height = 6)

rm(jt_od_devices_ordered)
gc()


##################### II. Aggregated to unordered pairs for main analysis  #####################
{
  jt_od_devices <- data.table(jt_od_devices)
  jt_od_devices_unordered <- jt_od_devices[,.(pair_obs = .N,
                                              work_devices = sum(work_devices, na.rm = T)/12,
                                              home_devices = sum(home_devices, na.rm = T)/12,
                                              device_count = sum(device_count, na.rm =T)/12,
                                              time_cost = mean(time_cost, na.rm =T),
                                              edd = edd[1],
                                              edd_as = edd_as[1],
                                              edd_bl = edd_bl[1],
                                              edd_hs = edd_hs[1],
                                              edd_inc = edd_inc[1],
                                              inc_max = max(d_MedianHhIncome[1], o_MedianHhIncome[1]),
                                              inc_min = min(d_MedianHhIncome[1], o_MedianHhIncome[1]),
                                              df_gender = abs(d_PctFemale[1] - o_PctFemale[1])/100, 
                                              df_carowner = abs(d_PctNoCar[1] - o_PctNoCar[1])/100, 
                                              df_age = abs(d_MedianAge[1] - o_MedianAge[1])/100, 
                                              df_hhsize = abs(d_HHSize[1] - o_HHSize[1])/100, 
                                              df_homeowner = abs(d_PctRenter[1] - o_PctRenter[1])/100, 
                                              pair_jobs = d_cbg_jobs[1] + o_cbg_jobs[1],
                                              jobs_max = max(d_cbg_jobs[1], o_cbg_jobs[1]),
                                              jobs_min = min(d_cbg_jobs[1], o_cbg_jobs[1]),
                                              pair_pop =  d_TotalPax[1] + o_TotalPax[1],
                                              pop_max = max(d_TotalPax[1], o_TotalPax[1]),
                                              pop_min = min(d_TotalPax[1], o_TotalPax[1]),
                                              pair_shops = d_cbg_amenity[1] + o_cbg_amenity[1],
                                              shops_max = max(d_cbg_amenity[1], o_cbg_amenity[1]),
                                              shops_min = min(d_cbg_amenity[1], o_cbg_amenity[1]),
                                              PLACENAME = d_PlACENAME[1]), list(pair)]
  
 
  dim(jt_od_devices_unordered)
  jt_od_devices_unordered <- jt_od_devices_unordered[!str_detect(pair, "80319800001")] # Denver airport obnormally large number, 478 observations
  
  
  # summary plots
  jt_od_devices_unordered$time_bin <- cut(jt_od_devices_unordered$time_cost, c(seq(-.1, 60, 5), 85))
  table(jt_od_devices_unordered$time_bin) 
  hist(jt_od_devices_unordered$time_cost)
  
  jt_od_devices_unordered_sum <- jt_od_devices_unordered[,.(ave_time = mean(time_cost),
                                                            ave_edd = mean(edd),
                                                            ave_inc = mean(edd_inc, na.rm = T),
                                                            home_devices = mean(home_devices),
                                                            home_devices_se = sd(home_devices)/sqrt(.N),
                                                            work_devices = mean(work_devices),
                                                            work_devices_se = sd(work_devices)/sqrt(.N),
                                                            obs = .N), list(time_bin)]
  
  
  distance_cor_1 <- ggplot(jt_od_devices_unordered_sum %>% arrange(ave_time)) +
    geom_point(aes(y = ave_edd, x = ave_time, size = obs), alpha = .5) +
    geom_path(aes(y = ave_edd, x = ave_time), alpha = .5) +
    labs(y = "average Euclidean racial/ethnic distance", x = "average travel time") + 
    theme_classic()
  
  distance_cor_2 <- ggplot(jt_od_devices_unordered_sum %>% arrange(ave_time)) +
    geom_point(aes(x = ave_time, y = ave_inc, size = obs), alpha = .5) +
    geom_path(aes(x =  ave_time, y = ave_inc), alpha = .5) +
    labs(y = "average Euclidean income distance", x = "average travel time") + 
    theme_classic()
  
  jt_od_devices_unordered$inc_bin <- cut(jt_od_devices_unordered$edd_inc, c(-.1, .05, seq(.1, .8, .1), 1)) # some cbg does not have income categories
  table(jt_od_devices_unordered$inc_bin)
  jt_od_devices_unordered_sum <- jt_od_devices_unordered[,.(ave_edd = mean(edd,na.rm = T),
                                                            ave_time = mean(time_cost,na.rm = T),
                                                            edd_inc = mean(edd_inc,na.rm = T),
                                                            home_devices = mean(home_devices,na.rm = T),
                                                            home_devices_se = sd(home_devices)/sqrt(.N),
                                                            work_devices = mean(work_devices),
                                                            work_devices_se = sd(work_devices)/sqrt(.N),
                                                            obs = .N), list(inc_bin)]

  

  distance_cor_3 <- ggplot(jt_od_devices_unordered_sum[!is.na(inc_bin)] %>% arrange(edd_inc)) +
    geom_point(aes(y = ave_edd, x = edd_inc, size = obs),  alpha = .5) +
    geom_path(aes(y = ave_edd, x = edd_inc), alpha = .5) +
    labs(y = "average racial distance", x = "average income distance") + 
    theme_classic()
  
 
  # Figure S1
  distance_cor_1 + theme(legend.position = "none")|distance_cor_2+ theme(legend.position = "none")|distance_cor_3
  # ggsave("scatter_all_cities_cor.png", width = 13, height = 4)
  

  jt_od_devices_unordered_sum <- jt_od_devices_unordered[,.(ave_edd = mean(edd),
                                                            edd_inc = mean(edd_inc,na.rm = T),
                                                            ave_time = mean(time_cost),
                                                            home_devices = sum(home_devices),
                                                            work_devices = sum(work_devices),
                                                            obs = .N), list(PLACENAME)]
  
  dist1 <- ggplot(jt_od_devices_unordered_sum) +
    geom_point(aes(x = ave_edd, y = edd_inc, size = home_devices/1000000), shape = 1, alpha = .35) +
    geom_smooth(aes(x = ave_edd, y = edd_inc), method = "lm", fill = "grey20", alpha = .25, color = "grey20") +
    geom_label(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
                                                    home_devices> 15034015], aes(x = ave_edd-.005, y = edd_inc+.005, label = PLACENAME), alpha = 0, label.size = 0, size = 3) + 
    geom_point(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
                                                      home_devices> 15034015], aes(x = ave_edd, y = edd_inc, size = home_devices/1000000), alpha = 0.2) + 
    labs(x = "average racial distance", y =  "average income distance", size = "device count (million)") +
    theme_classic()
  
  dist2 <- ggplot(jt_od_devices_unordered_sum) +
    geom_point(aes(x = ave_time, y = ave_edd, size = home_devices/1000000), alpha = .25, shape  = 1) +
    geom_smooth(aes(x = ave_time, y = ave_edd), method = "lm", fill = "grey20", color = "grey20", alpha = .25) +
    geom_label(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
    home_devices> 15034015], aes(x = ave_time-.005, y = ave_edd+.005, label = PLACENAME), alpha = 0, label.size = 0, size = 3) + 
    geom_point(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
      home_devices> 15034015], aes(x = ave_time, y = ave_edd, size = home_devices/1000000), alpha = 0.2) + 
    labs(y = "average racial distance", x =  "average travel time", size = "device count (million)") +
    theme_classic()
  

  dist3 <- ggplot(jt_od_devices_unordered_sum) +
    geom_point(aes(x = ave_time, y = edd_inc, size = home_devices/1000000), alpha = .25, shape  = 1) +
    geom_smooth(aes(x = ave_time, y = edd_inc), method = "lm", fill = "grey20", color = "grey20", alpha = .25) +
    geom_label(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
                                                  home_devices> 15034015], aes(x = ave_time-.005, y = edd_inc+.005, label = PLACENAME), alpha = 0, label.size = 0, size = 3) + 
    geom_point(data = jt_od_devices_unordered_sum[#ave_edd > .32|ave_edd < .05|edd_inc > .3|edd_inc < .05|
                                                  home_devices> 15034015], aes(x = ave_time, y = edd_inc, size = home_devices/1000000), alpha = 0.2) + 
    labs(y = "average income distance", x =  "average travel time", size = "device count (million)") +
    theme_classic()
  
  
  # Figure 6
  (dist2 + theme(legend.position = "none")|dist3 + theme(legend.position = "none")|dist1) 
  # ggsave("dist_measure_scatter_updated.png", width = 10, height = 3)
  
  
  # Table S2: correlation between different types of distances within each city
  jt_od_devices_unordered$time_cost_sq <- (jt_od_devices_unordered$time_cost)^2
  l0 <- feols(edd ~ time_cost +  time_cost_sq|PLACENAME, data = jt_od_devices_unordered) 
  l1 <- feols(edd_inc ~ time_cost + time_cost_sq |PLACENAME, data = jt_od_devices_unordered) 
  l2 <- feols(edd ~ edd_inc|PLACENAME, data = jt_od_devices_unordered) 
  etable(l0, l1, l2,
         digits = 4,
         tex = T, 
         dict = c("edd" = "race dist",
                  "edd_bl" = "Black dist",
                  "edd_as" = "Asian dist",
                  "edd_hs" = "Hispanic dist",
                  "edd_inc" = "income dist",
                  "time_cost" = "travel time",
                  "PLACENAME" = "City FE"))
  

  
  # unordered pairs: local analysis 
  fm_time <- formula(log(home_devices + 1) ~ time_cost  + edd + edd_inc  + df_carowner +  df_gender +  df_age + df_hhsize + log(pair_jobs) + log(pair_pop) + log(pair_shops))
  
  # log(time_cost + 1) and sqrt(time_cost + 1) as robustness checks
  fm_logtime <- formula(log(home_devices + 1) ~ log(time_cost + 1)  + edd + edd_inc  + df_carowner +  df_gender +  df_age + df_hhsize + log(pair_jobs) + log(pair_pop) + log(pair_shops))
  fm_sqrttime <- formula(log(home_devices + 1) ~ sqrt(time_cost + 1)  + edd + edd_inc  + df_carowner +  df_gender +  df_age + df_hhsize + log(pair_jobs) + log(pair_pop) + log(pair_shops))
  
  
  
  local_est <- function(fip){
    local_data <- jt_od_devices_unordered[PLACENAME == fip,][!is.na(pair_jobs) & !is.na(edd_inc)][time_cost < 120]
    if(nrow(local_data) > 6){
      l2.lc <- feols(fm, data = local_data)
      ct <- l2.lc$coeftable
      ct <- ct[str_detect(rownames(ct), "time_cost|edd$|edd_inc"), 1:2]
      cdt <- data.frame(unlist(ct)  %>% t())
      names(cdt) <- c("coef_time", "coef_edd", "coef_inc", "se_time", "se_edd", "se_inc")
      cdt$edd_time_ratio <- cdt$coef_edd/cdt$coef_time
      cdt$inc_time_ratio <- cdt$coef_inc/cdt$coef_time
      cdt$rac_inc_ratio <- cdt$coef_edd/cdt$coef_inc
      
      edd_time_se <- deltamethod(~x2/x1, l2.lc$coefficients[2:3], vcov(l2.lc)[2:3,2:3],ses = T)
      inc_time_se <- deltamethod(~x2/x1, l2.lc$coefficients[c(2,4)], vcov(l2.lc)[c(2,4),c(2,4)],ses = T)
      rac_inc_se <- deltamethod(~x2/x1, l2.lc$coefficients[c(4,3)], vcov(l2.lc)[c(4,3),c(4,3)],ses = T)
      
      cdt$edd_as_time_pct <- (exp(cdt$coef_edd)-1)/(exp(cdt$coef_time)-1)
      cdt$inc_as_time_pct <- (exp(cdt$coef_inc)-1)/(exp(cdt$coef_time)-1)
      
      edd_as_time_pct_se <- deltamethod(~(exp(x2)-1)/(exp(x1)-1), l2.lc$coefficients[2:3], vcov(l2.lc)[2:3,2:3],ses = T)
      inc_as_time_pct_se <- deltamethod(~(exp(x2)-1)/(exp(x1)-1), l2.lc$coefficients[c(2,4)], vcov(l2.lc)[c(2,4),c(2,4)],ses = T)
      
      cdt <- cbind("PLACENAME" = fip, "obs" = l2.lc$nobs,
                   cdt, 
                   edd_time_se,
                   inc_time_se,
                   rac_inc_se,
                   edd_as_time_pct_se,
                   inc_as_time_pct_se)
      return(cdt)
    }else{
      print("******wrong******")
      cdt <- {}
    }
    
  }
  
  fm <- fm_time
  ct_list <- lapply(unique(jt_od_devices_unordered$PLACENAME), local_est)
  ct_local <- rbindlist(ct_list)
  
  summary(ct_local) # 498 cities
  hist(log(ct_local$obs)) #min obs 120
  table(ct_local$obs > 500)
  table(ct_local$obs > 1000)
  
  summary(ct_local$coef_time/ct_local$se_time) # min t value -7, max t -838
  summary(ct_local)
  
  
}

# add city average distance
jt_od_devices_unordered <- data.table(jt_od_devices_unordered)
od_sum <- jt_od_devices_unordered[,.(time_cost_av = sum(pair_pop*time_cost, na.rm = T)/sum(pair_pop, na.rm = T),
                                     sqrt_time_cost_av = sum(pair_pop*sqrt(time_cost), na.rm = T)/sum(pair_pop, na.rm = T),
                                     time_cost_min = min(time_cost),
                                     time_cost_max = max(time_cost),
                                     edd_av = sum(pair_pop*edd, na.rm = T)/sum(pair_pop, na.rm = T),
                                     edd_min = min(edd),
                                     edd_max = max(edd),
                                     edd_inc_av = sum(pair_pop*edd_inc, na.rm = T)/sum(pair_pop, na.rm = T),
                                     edd_inc_min = min(edd_inc),
                                     edd_inc_max = max(edd_inc)), list(PLACENAME)]

ct_local_jt <- ct_local %>% left_join(od_sum, "PLACENAME")
# fwrite(ct_local_jt, "coef_500cities_202609.csv")
# fwrite(ct_local_jt, "coef_500cities_202609_logtime.csv") # change fm <- fm_logtime in function local_est
# fwrite(ct_local_jt, "coef_500cities_202609_sqrttime.csv") # change fm <- fm_sqrttime in function local_est









