# city level analysis
library(data.table)
library(ggplot2)
library(fixest)
library(dplyr)
library(ggrepel)
library(patchwork)
library(stringr)
library(ggrepel)
options(scipen=1000000)

etable_dict = c("PctTrnCom" = "share:transit commuting",
         "PctActiveCom"= "share:active modes commuting",
         "PctBlack" = "share:Black",
         "PctHisp"= "share:Hispanic",
         "PctAsian" = "share:Asian",
         "pctwater" = "share: water area",
         "AreaTRI_Mean" = "area ruggedness",
         "dissim_black" = "dissim:Black",
         "dissim_hisp" = "dissim:Hispanic",
         "dissim_asian" = "dissim:Asian",
         "dissim_income" = "dissim:income",
         "log(acreurb)" = "log(urban area size)",
         "log(areaacre)" = "log(total city area)",
         "log(poptot)" = "log(pop)",
         "log(popden)" = "log(pop density)",
         "log(medhhinc)" = "log(med hh inc)",
         "poptot>100000TRUE" = "pop > 100k",
         "dem_margin" = "democrats margin",
         "regionSoutheast" = "  Southeast",
         "regionWest" = "  West",
         "regionMidWest" = "  MidWest",
         "regionSouthwest" = "  Southwest")

# city-level coefficients
coef <- fread("replication_folder/modelling_data/coef_500cities_202609.csv")
coef$norm_edd_time_ratio <- coef$edd_time_ratio/coef$time_cost_av
coef$norm_edd_time_ratio_se <- coef$edd_time_se/sqrt(coef$time_cost_av)
coef$norm_inc_time_ratio <- coef$inc_time_ratio/coef$time_cost_av
coef$norm_inc_time_ratio_se <- coef$inc_time_se/sqrt(coef$time_cost_av)

# city-level attributes
city_att <- fread("replication_folder/modelling_data/city_attributes_500cities.csv")
coef <- coef[PLACENAME != "Honolulu, HI" & PLACENAME != "Anchorage, AK"] #"Anchorage, AK" missing land value
length(unique(coef$PLACENAME)) # 498 cities

coef <- coef %>%
  left_join(city_att, c("PLACENAME" = "city"))

coef <- data.table(coef) 
summary(coef)

coef$region <- factor(coef$region, levels = c("NorthEast", unique(coef$region)[-1]))
coef$sqPctBac <- (coef$PctBac)^2


# missing values (voting data)
table(is.na(coef$dem_margin)) # 296 non-NAs
summary(coef$poptot)

# check correlation
covtb <- cor(coef[!is.na(popden)&!is.na(dem_margin)][, c("coef_time", "coef_edd", "coef_inc", "edd_time_ratio", "edd_as_time_pct","inc_time_ratio", "inc_as_time_pct", "poptot", "popden")])
covtb <- data.frame(covtb) %>% round(2)
covtb[upper.tri(covtb)] <-  NA
# fwrite(covtb, "500cities_corr_table.csv")

########################################################
# ggplot full ranking Appendix Section 9
{
  lmdata_oder <- arrange(coef, coef_time)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  full_table <- lmdata_oder[,c("PLACENAME", "coef_time", "se_time")]
  # stargazer::stargazer(full_table,  summary = F)
  
  rank1 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0, alpha = .5) + 
    geom_vline(xintercept = mean(lmdata_oder$coef_time), color = "grey40", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = coef_time), size = .25, color = "grey40") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_time-.05, label = PLACENAME), check_overlap = T) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_time)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = coef_time - 1.96*se_time, xmax = coef_time+ 1.96*se_time), alpha = .3, color = "grey40") +
    geom_label(data = lmdata_oder[1:3,], aes(x = mean(lmdata_oder$coef_time), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$coef_time), 2)), label.size = 0, alpha = 0.25, size = 4) +
    labs(x = "travel time coef", y = NULL, title = "(1) travel time coef") +
    xlim(-.5, .2) +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  
  
  lmdata_oder <- arrange(coef, coef_inc)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  lmdata_oder <-lmdata_oder[!is.na(PLACENAME)]
  rank2 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0, alpha = .5) + 
    geom_vline(xintercept = mean(lmdata_oder$coef_inc), linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = coef_inc), size = .25) +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_inc-.35, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_inc)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = coef_inc - 1.96*se_inc, xmax = coef_inc+ 1.96*se_inc), alpha = .2) +
    labs(title = "             Coef of income distance", y = NULL, x = "")+
    geom_label(data = lmdata_oder[1,],aes(x = mean(lmdata_oder$coef_inc) + .15, y = 50, angle = 90), label = paste0("mean ", round(mean(lmdata_oder$coef_inc), 2)), label.size = 0, alpha = 0, color = "red") +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  
  lmdata_oder <- arrange(coef, coef_edd)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  
  rank3 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0, alpha = .5) + 
    geom_vline(xintercept = mean(lmdata_oder$coef_edd), linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = coef_edd), size = .25) +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_edd-.75, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = coef_edd)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = coef_edd - 1.96*se_edd, xmax = coef_edd+ 1.96*se_edd), alpha = .3) +
    labs(x = "", y = NULL, title = "            Coef of racial distance")+
    geom_label(data = lmdata_oder[1,],aes(x = mean(lmdata_oder$coef_edd) + .25, y = 50, angle = 90), label = paste0("mean ", round(mean(lmdata_oder$coef_edd), 2)), label.size = 0, alpha = 0, color = "red") +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  # Figure S3(a)
  rank3|rank2
  # ggsave("ranking_coef_edd_updated.png", width = 10, height = 6)



  lmdata_oder <- arrange(coef, edd_time_ratio)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  full_table <- lmdata_oder[,c("PLACENAME", "edd_time_ratio", "edd_time_se")]
  # stargazer::stargazer(full_table,  summary = F)
  table(lmdata_oder$edd_time_ratio>0 & lmdata_oder$edd_time_ratio/lmdata_oder$edd_time_se >1.96)
  
  rank4 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0) + 
    geom_vline(xintercept = mean(lmdata_oder$edd_time_ratio), color = "coral2", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = edd_time_ratio), size = .05, color = "coral2") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = edd_time_ratio-.75, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = edd_time_ratio)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = edd_time_ratio - 1.96*edd_time_se, xmax = edd_time_ratio+ 1.96*edd_time_se), alpha = .3, color = "coral2") +
    labs(x = "time equivalent cost (minute)", y = NULL, title = "(2) race coef/time coef")+
    geom_label(data = lmdata_oder[1:3,], aes(x = mean(lmdata_oder$edd_time_ratio), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$edd_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4 ) +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  
  
  lmdata_oder <- arrange(coef, inc_time_ratio)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  full_table <- lmdata_oder[,c("PLACENAME", "inc_time_ratio", "inc_time_se")]
  # stargazer::stargazer(full_table, summary = F)
  
  table(lmdata_oder$inc_time_ratio>0 & lmdata_oder$inc_time_ratio/lmdata_oder$inc_time_se >1.96)
  rank5 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0) + 
    geom_vline(xintercept = mean(lmdata_oder$inc_time_ratio), color = "cyan4", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = inc_time_ratio), size = .05, color = "cyan4") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = inc_time_ratio-.75, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = inc_time_ratio)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = inc_time_ratio - 1.96*inc_time_se, xmax = inc_time_ratio+ 1.96*inc_time_se), alpha = .3, color = "cyan4") +
    labs(x = "time equivalent cost (minute)", y = NULL, title = "(3) income coef/time coef") +
    geom_label(data = lmdata_oder[1:3,], aes(x = mean(lmdata_oder$inc_time_ratio), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$inc_time_ratio), 2)), label.size = 0, alpha = 0.25, size = 4) +
    # lims(x = c(-.6, 0)) + 
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  lmdata_oder <- arrange(coef, norm_edd_time_ratio)
  lmdata_oder$norm_edd_time_ratio_se <- lmdata_oder$edd_time_se/sqrt(lmdata_oder$time_cost_av)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  full_table <- lmdata_oder[,c("PLACENAME", "norm_edd_time_ratio", "norm_edd_time_ratio_se")]
  # stargazer::stargazer(full_table, summary = F)
  
  rank6 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0, alpha = .5) + 
    geom_vline(xintercept = mean(lmdata_oder$edd_time_ratio/lmdata_oder$time_cost_av), color = "coral2", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = edd_time_ratio/time_cost_av), size = .5, color = "coral2") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = edd_time_ratio/time_cost_av-.05, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = edd_time_ratio/time_cost_av)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = edd_time_ratio/time_cost_av - 1.96*edd_time_se/sqrt(time_cost_av), xmax = edd_time_ratio/time_cost_av+ 1.96*edd_time_se/sqrt(time_cost_av)), alpha = .3, color = "coral2") +
    geom_label(data = lmdata_oder[1:3,], aes(x = mean(lmdata_oder$edd_time_ratio/lmdata_oder$time_cost_av), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$edd_time_ratio/lmdata_oder$time_cost_av), 2)), label.size = 0, alpha = 0.25, size = 4) +
    labs(x = "share of average travel time", y = NULL, title = "(5) race coef/time coef normalized") +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  lmdata_oder <- arrange(coef, norm_inc_time_ratio)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  lmdata_oder$norm_inc_time_ratio_se <- lmdata_oder$inc_time_se/sqrt(lmdata_oder$time_cost_av)
  full_table <- lmdata_oder[,c("PLACENAME", "norm_inc_time_ratio", "norm_inc_time_ratio_se")]
  # stargazer::stargazer(full_table, summary = F)
  rank7 <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0, alpha = .5) + 
    geom_vline(xintercept = mean(lmdata_oder$inc_time_ratio/lmdata_oder$time_cost_av), color = "cyan4", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = inc_time_ratio/time_cost_av), size = .5, color = "cyan4") +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = inc_time_ratio/time_cost_av)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = inc_time_ratio/time_cost_av - 1.96*inc_time_se/sqrt(time_cost_av), xmax = inc_time_ratio/time_cost_av+ 1.96*inc_time_se/sqrt(time_cost_av)), alpha = .3, color = "cyan4") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = inc_time_ratio/time_cost_av-.05, label = PLACENAME), size = 4) +
    geom_label(data = lmdata_oder[1:3,],  aes(x = mean(lmdata_oder$inc_time_ratio/lmdata_oder$time_cost_av), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$inc_time_ratio/lmdata_oder$time_cost_av), 2)), label.size = 0, alpha = 0.25, size = 4) +
    labs(x = "share of average travel time", y = NULL, title = "(6) income coef/time coef normalized") +
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  
  # difference between means
  coef$dif_race_inc <- coef$edd_time_ratio - coef$inc_time_ratio
  coef$dif_race_inc_se <- sqrt(coef$edd_time_se^2 + coef$inc_time_se^2)
  table(abs(coef$dif_race_inc/coef$dif_race_inc_se) > 1.96 & coef$dif_race_inc > 0) # 323
  table(abs(coef$dif_race_inc/coef$dif_race_inc_se) > 1.96 & coef$dif_race_inc < 0) # 42
  
  
  lmdata_oder <- arrange(coef, dif_race_inc)
  lmdata_oder$PLACENAME <- factor(lmdata_oder$PLACENAME, levels = lmdata_oder$PLACENAME)
  rank_rac_inc_dif <- ggplot(lmdata_oder) +
    geom_vline(xintercept = 0) + 
    geom_vline(xintercept = mean(lmdata_oder$dif_race_inc), color = "blue", linetype = "dashed") + 
    geom_point(aes(y = PLACENAME, x = dif_race_inc), size = .05, color = "blue") +
    geom_text_repel(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = dif_race_inc-.75, label = PLACENAME)) +
    geom_point(data = lmdata_oder[poptot > 1500000], aes(y = PLACENAME, x = dif_race_inc)) +
    geom_errorbarh(aes(y = PLACENAME, xmin = dif_race_inc - 1.96*dif_race_inc_se, xmax = dif_race_inc+ 1.96*dif_race_inc_se), alpha = .3, color = "blue") +
    labs(x = "dif in time equivalent cost (minute)", y = NULL, title = "(4) dif in race and income eqv. costs") +
    geom_label(data = lmdata_oder[1:10,], aes(x = mean(lmdata_oder$dif_race_inc), y = 30), label = paste0("mean = ", round(mean(lmdata_oder$dif_race_inc), 2)), label.size = 0, alpha = 0.25, size = 4) +
    # lims(x = c(-.6, 0)) + 
    theme_classic() + 
    theme(axis.text.y=element_blank(), 
          axis.ticks.y=element_blank()) 
  
  # Figure 2
  (rank1|rank4|rank5)/(plot_spacer())/(rank_rac_inc_dif + rank6 + rank7) +plot_layout(heights = c(5, .1, 5))
  # ggsave("ranking_coef_edd_norm_updated_2026.png", width = 10, height = 10)
}


# report full table Appendix Section 11
{
  full_table <- lmdata_oder[,c("PLACENAME", "time_cost_av", "edd_time_ratio", "edd_time_se", "inc_time_ratio", "inc_time_se", "norm_edd_time_ratio", "norm_edd_time_ratio_se", "norm_inc_time_ratio", "norm_inc_time_ratio_se")]
  full_table <- arrange(full_table, -edd_time_ratio)
  stargazer::stargazer(full_table, summary = F, digits = 2)
}


#############################################
#  naive regression results 
{
  lmdata <- coef#[!is.na(dem_margin)]
  lmdata <- data.table(lmdata)
  
  lmdata$PctActiveCom <- lmdata$PctActiveCom/100
  lmdata$PctTrnCom <- lmdata$PctTrnCom/100
  lmdata$PctBlack <- lmdata$PctBlack/100
  lmdata$PctHisp <- lmdata$PctHisp/100
  lmdata$PctAsian <- lmdata$PctAsian/100
  
  lmdata$Black_dominate <- lmdata$PctBlack > .55
  lmdata$Hisp_dominate <- lmdata$PctHisp > .55
  lmdata$Asian_dominate <- lmdata$PctAsian > .55
  lmdata$AreaTRI_Mean <- lmdata$AreaTRI_Mean/100
  
  lmdata$pct_city_pop <- lmdata$poptot/lmdata$cbsa_pop
  table(lmdata$pct_city_pop > .2)
  
  sum_lmdata <- lmdata[, c("time_cost_av", 
                           "poptot", "popden", "AreaTRI_Mean", "medhhinc", "pctwater",
                           "PctBlack", "PctHisp", "PctAsian", 
                           "dissim_hisp", "dissim_black","dissim_asian", "dissim_income",
                           "PctTrnCom", "PctActiveCom")]
  names(sum_lmdata) <- c("average travel time (min)",
                         "pop",
                         "pop density",
                         "ruggedness (100m)",
                         "median household income ($)",
                         "water area",
                         "Black share",
                         "Hispanic share",
                         "Asian share",
                         "Dissim Hisp", "Dissim Black","Dissim Asian", "Dissim income",
                         "commuters using transit",
                         "commuters using active travel")
  
  stargazer::stargazer(sum_lmdata)
  
  stargazer::stargazer(lmdata[, c("Black_dominate", "Hisp_dominate", "Asian_dominate")])
  
  
  outcome_coef <- "c(-coef_time, -coef_edd, -coef_inc)" 
  outcome_ratio <- "c(edd_time_ratio, inc_time_ratio, norm_edd_time_ratio, norm_inc_time_ratio)" 
  
  # baseline selection of control variables + dissimilarities
  lm_dissim <- feols(c(-coef_time, -coef_edd, -coef_inc, edd_time_ratio, inc_time_ratio, norm_edd_time_ratio, norm_inc_time_ratio) 
                     ~ log(poptot) + log(popden)  + pctwater + AreaTRI_Mean  +   log(medhhinc)  + 
                       PctBlack + PctHisp + PctAsian  + 
                       + dissim_black + dissim_hisp + dissim_asian + dissim_income
                     + PctTrnCom + PctActiveCom 
                     + region,data = lmdata)
  # Table S5
  etable(lm_dissim,
         se.below = T,
         dict = etable_dict,
         order = c("coef_time"),
         tex = T, 
         digits = 3)
  
  # baseline selection of control variables + dissimilarities + whether being part of a a metro matters
  lmdata$dominant_in_metro <- lmdata$poptot/lmdata$cbsa_pop >.5
  table(lmdata$dominant_in_metro)
  hist(lmdata$poptot/lmdata$cbsa_pop)
  lmdata$share_in_metro <- cut(lmdata$poptot/lmdata$cbsa_pop, c(0, .05, .25, .5, .75, 1))
  table(lmdata$share_in_metro)
  
  lm_dissim <- feols(c(-coef_time, -coef_edd, -coef_inc, edd_time_ratio, inc_time_ratio, norm_edd_time_ratio, norm_inc_time_ratio) 
                     ~ log(poptot) + log(popden)  + pctwater + AreaTRI_Mean  +   log(medhhinc)  + 
                       PctBlack + PctHisp + PctAsian  + 
                       + dissim_black + dissim_hisp + dissim_asian + dissim_income
                     + PctTrnCom + PctActiveCom + dominant_in_metro +
                       + region,data = lmdata)
  # Table S6
  etable(lm_dissim,
         se.below = T,
         dict = etable_dict,
         order = c("coef_time"),
         tex = T, 
         digits = 3)

}



####################################################################
# monte carlo regression 

{
  est_list_time <- {}
  est_list_edd <- {}
  est_list_inc <- {}
  est_list_edd_ratio <- {}
  est_list_inc_ratio <- {}
  est_list_edd_ratio_norm <- {}
  est_list_inc_ratio_norm <- {}
  fit_rsq <- {}
  
  lmfm_trial <- formula(c(-coef_time_per_trial, -coef_edd_per_trial, -coef_inc_per_trial, coef_edd_time_ratio_per_trial, coef_inc_time_ratio_per_trial, coef_edd_time_ratio_norm_per_trial, coef_inc_time_ratio_norm_per_trial) ~ 
                          log(poptot) + log(popden)  + pctwater + AreaTRI_Mean  +   log(medhhinc)  + 
                          PctBlack + PctHisp + PctAsian  + 
                          dissim_black + dissim_hisp + dissim_asian + dissim_income +
                          PctTrnCom + PctActiveCom + region)
  
  # random draws of outcome estimates x 1000
  for(i in 0:999){
    set.seed(1000000 + i)
    lmdata$coef_time_per_trial <- rnorm(nrow(lmdata), lmdata$coef_time, lmdata$se_time)
    lmdata$coef_edd_per_trial <- rnorm(nrow(lmdata), lmdata$coef_edd, lmdata$se_edd)
    lmdata$coef_inc_per_trial <- rnorm(nrow(lmdata), lmdata$coef_inc, lmdata$se_inc)
    
    lmdata$coef_edd_time_ratio_per_trial <- rnorm(nrow(lmdata), lmdata$edd_time_ratio, lmdata$edd_time_se)
    lmdata$coef_inc_time_ratio_per_trial <- rnorm(nrow(lmdata), lmdata$inc_time_ratio, lmdata$inc_time_se)
    
    lmdata$coef_edd_time_ratio_norm_per_trial <- rnorm(nrow(lmdata), lmdata$norm_edd_time_ratio, lmdata$norm_edd_time_ratio_se)
    lmdata$coef_inc_time_ratio_norm_per_trial <- rnorm(nrow(lmdata), lmdata$norm_inc_time_ratio, lmdata$norm_inc_time_ratio_se)
    
    
    lm_trial <- feols(lmfm_trial, lmdata)
    
    
    
    est_list_time <- rbind(est_list_time, t(lm_trial$`lhs: -coef_time_per_trial`$coeftable[, 1]))
    est_list_edd <- rbind(est_list_edd, t(lm_trial$`lhs: -coef_edd_per_trial`$coeftable[, 1]))
    est_list_inc <- rbind(est_list_inc, t(lm_trial$`lhs: -coef_inc_per_trial`$coeftable[, 1]))
    est_list_edd_ratio <- rbind(est_list_edd_ratio, t(lm_trial$`lhs: coef_edd_time_ratio_per_trial`$coeftable[, 1]))
    est_list_inc_ratio <- rbind(est_list_inc_ratio, t(lm_trial$`lhs: coef_inc_time_ratio_per_trial`$coeftable[, 1]))
    est_list_edd_ratio_norm <- rbind(est_list_edd_ratio_norm, t(lm_trial$`lhs: coef_edd_time_ratio_norm_per_trial`$coeftable[, 1]))
    est_list_inc_ratio_norm <- rbind(est_list_inc_ratio_norm, t(lm_trial$`lhs: coef_inc_time_ratio_norm_per_trial`$coeftable[, 1]))
    fit_rsq <- rbind(fit_rsq, 
                     cbind(r2(lm_trial$`lhs: -coef_time_per_trial`)[3],
                           r2(lm_trial$`lhs: -coef_edd_per_trial`)[3],
                           r2(lm_trial$`lhs: -coef_inc_per_trial`)[3],
                           r2(lm_trial$`lhs: coef_edd_time_ratio_per_trial`)[3],
                           r2(lm_trial$`lhs: coef_inc_time_ratio_per_trial`)[3],
                           r2(lm_trial$`lhs: coef_edd_time_ratio_norm_per_trial`)[3],
                           r2(lm_trial$`lhs: coef_inc_time_ratio_norm_per_trial`)[3]))
    
  }
  
  # Rsquares
  summary(fit_rsq)
  
  monte_carlo_var  <- c("est_list_time", 
                        "est_list_edd", 
                        "est_list_inc", 
                        "est_list_edd_ratio", 
                        "est_list_inc_ratio", 
                        "est_list_edd_ratio_norm", 
                        "est_list_inc_ratio_norm")
  monte_carlo_names <- c("outcome.time coef (absolute value)",
                         "outcome.race distance coef (absolute value)", 
                         "outcome.income distance coef (absolute value)", 
                         "outcome.cross-race time equivelant", 
                         "outcome.cross-income time equivelant", 
                         "outcome.cross-race time equivelant normalized", 
                         "outcome.cross-income time equivelant normalized")
  
  mc_collect <- {}
  for(i in 1:7){
    monte_carlo_est <- data.table(get(monte_carlo_var[i]))
    
    names(monte_carlo_est) <- rownames(lm_trial$`lhs: -coef_time_per_trial`$coeftable)
    mc_sum <- monte_carlo_est[, .(
      log.pop = mean(`log(poptot)`),
      log.pop_sd = sd(`log(poptot)`),
      log.pop.density = mean(`log(popden)`),
      log.pop.density_sd = sd(`log(popden)`),
      pct.water = mean(pctwater),
      pct.water_sd = sd(pctwater),
      ruggedness = mean(AreaTRI_Mean),
      ruggedness_sd = sd(AreaTRI_Mean),
      log.medhhincome = mean(`log(medhhinc)`),
      log.medhhincome_sd = sd(`log(medhhinc)`),
      pct.Black = mean(PctBlack),
      pct.Black_sd = sd(PctBlack),
      pct.Hisp = mean(PctHisp),
      pct.Hisp_sd = sd(PctHisp),
      pct.Asian = mean(PctAsian),
      pct.Asian_sd = sd(PctAsian),
      dissimilarity.Black = mean(dissim_black),
      dissimilarity.Black_sd = sd(dissim_black),
      dissimilarity.Hisp = mean(dissim_hisp),
      dissimilarity.Hisp_sd = sd(dissim_hisp),
      dissimilarity.Asian = mean(dissim_asian),
      dissimilarity.Asian_sd = sd(dissim_asian),
      dissimilarity.income = mean(dissim_income),
      dissimilarity.income_sd = sd(dissim_income),
      pct.transit = mean(PctTrnCom),
      pct.transit_sd = sd(PctTrnCom),
      pct.active.modes = mean(PctActiveCom),
      pct.active.modes_sd = sd(PctActiveCom))] %>% t() %>% data.frame()
    
    
    mc_sum <- data.frame(mc_sum,
                         "outcome" = monte_carlo_names[i],
                         "factor" = rownames(mc_sum) )
    
    if(i ==1){
      mc_collect <-  mc_sum
    }else{
      mc_collect <- rbind(mc_collect, mc_sum)
    }
    
  }
  
  mc_collect$outcome <- str_remove_all(mc_collect$outcome, "outcome.")
  mc_collect$factor <- str_remove_all(mc_collect$factor, "_sd")
  names(mc_collect)[1] <- "value"
  
  mc_collect$factor <- factor(mc_collect$factor, levels = unique(mc_collect$factor))
  mc_collect$outcome <- factor(mc_collect$outcome, levels = unique(mc_collect$outcome))
  
  dim(mc_collect) # 196 columns
  table(mc_collect$factor) #  14*14
  table(mc_collect$outcome) # 7*28

  }


# by all outcome
unique(mc_collect$factor)
nr <- nrow(mc_collect)

# plot by outcomes
mc_collect$value_label <- ifelse(abs(mc_collect$value) <.01, as.character(round(mc_collect$value, 4)), as.character(round(mc_collect$value, 2)))
mc_collect$t <- NA
mc_collect$t[!str_detect(rownames(mc_collect), "_sd")] <- mc_collect[seq(1, nrow(mc_collect), 2),]$value/mc_collect[-seq(1, nrow(mc_collect), 2),]$value
mc_collect_ratio <- mc_collect[mc_collect$outcome %in% c("time coef (absolute value)","cross-race time equivelant", "cross-income time equivelant", "cross-race time equivelant normalized", "cross-income time equivelant normalized"),]
mc_collect_ratio <- data.table(mc_collect_ratio)

mc_collect_ratio$outcome_wrap <- str_wrap(mc_collect_ratio$outcome, width=20)
mc_collect_ratio$outcome_wrap <- factor(mc_collect_ratio$outcome_wrap, levels = c("time coef (absolute\nvalue)", "cross-race time\nequivelant", "cross-income time\nequivelant", "cross-race\ntime equivelant\nnormalized", "cross-income\ntime equivelant\nnormalized"))

plot_mc <- ggplot(mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]) +
  geom_vline(xintercept = 0) +
  geom_col(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),][abs(t) >= 2], aes(y = factor, x = value), alpha = .6, width = .5) +
  geom_col(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),][abs(t) < 2], aes(y = factor, x = value), alpha = .3, width = .25) +
  geom_point(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),], aes(y = factor, x = value), color = "black",size =.25) +
  geom_text(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),], aes(y = factor, x = value, label = value_label), hjust = .5,  vjust = 1.5, angle = 0, size = 3) +
  # geom_text(data = mc_collect_ratio[7,], aes(y = factor, x = value, label = round(value, 4)), hjust = .5,  vjust = 1.5, angle = 0, size = 2.5) +
  geom_errorbar(aes(y = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$factor, xmax = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$value + 2*mc_collect_ratio[-seq(1, nrow(mc_collect_ratio), 2),]$value, xmin = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$value - 2*mc_collect_ratio[-seq(1, nrow(mc_collect_ratio), 2),]$value), alpha = .75, width = .1) +
  theme_classic() +
  facet_wrap(~outcome_wrap, ncol=5, scales = "free_x") +
  scale_y_discrete(guide = guide_axis(angle = 0), limits = rev(levels(mc_collect$factor)))  +
  labs(x = "", y = "") + 
  theme(legend.position = "none")

# Figure 4
  plot_mc
# ggsave("monte_carlo_city_factors_ratios_updated.png", width = 8, height = 5)

mc_collect_ratio <- mc_collect[mc_collect$outcome %in% c("race distance coef (absolute value)", "income distance coef (absolute value)"),]
plot_mc_coef <-ggplot(mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]) +
  geom_vline(xintercept = 0) +
  geom_col(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),], aes(y = factor, x = value), alpha = .35) +
  geom_point(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),], aes(y = factor, x = value), color = "black",size =.25) +
  geom_text(data = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),], aes(y = factor, x = value, label = value_label), hjust = .5,  vjust = 1.5, angle = 0, size = 2.5) +
  geom_errorbar(aes(y = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$factor, xmax = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$value + 2*mc_collect_ratio[-seq(1, nrow(mc_collect_ratio), 2),]$value, xmin = mc_collect_ratio[seq(1, nrow(mc_collect_ratio), 2),]$value - 2*mc_collect_ratio[-seq(1, nrow(mc_collect_ratio), 2),]$value), alpha = .75, width = .1) +
  theme_classic() +
  facet_wrap(~outcome, ncol=2, scales = "free_x") +
  scale_y_discrete(guide = guide_axis(angle = 0), limits = rev(levels(mc_collect_ratio$factor)))  +
  labs(x = "", y = "") + 
  theme(legend.position = "none")

# Figure S3b
plot_mc_coef
# ggsave("monte_carlo_city_factors_coef.png", width = 5, height = 5)



####################################################################
# aggregated time cost: coef * city average distance
lmdata$time_pred <- lmdata$time_cost_av* lmdata$coef_time
hist(lmdata$time_pred)

lmdata$edd_time_cost_pred <- lmdata$edd_av* lmdata$edd_time_ratio
lmdata$edd_time_cost_pred_se <- sqrt(lmdata$edd_av)*lmdata$edd_time_se
summary(lmdata$edd_time_cost_pred)
summary(lmdata$edd_time_cost_pred/lmdata$edd_time_cost_pred_se>1.96) # 

lmdata$inc_time_cost_pred <- lmdata$edd_inc_av* lmdata$inc_time_ratio
lmdata$inc_time_cost_pred_se <- sqrt(lmdata$edd_inc_av)*lmdata$inc_time_se
summary(lmdata$inc_time_cost_pred)
summary(lmdata$inc_time_cost_pred/lmdata$inc_time_cost_pred_se)
table(lmdata$inc_time_cost_pred/lmdata$inc_time_cost_pred_se< -1.96, lmdata$edd_time_cost_pred/lmdata$edd_time_cost_pred_se< -1.96)

lmdata$total_time_cost_pred <- lmdata$edd_time_cost_pred + lmdata$inc_time_cost_pred
summary(lmdata$total_time_cost_pred)
lmdata$total_time_cost_pred_se <- sqrt(lmdata$edd_time_cost_pred_se^2 + lmdata$inc_time_cost_pred_se^2)
summary(lmdata$total_time_cost_pred/lmdata$total_time_cost_pred_se)

summary(lmdata$total_time_cost_pred/lmdata$time_cost_av) # increased 30% of travel time
summary(lmdata$edd_time_cost_pred/lmdata$time_cost_av) # increased 18% of travel time
summary(lmdata$inc_time_cost_pred/lmdata$time_cost_av) # increased 11% of travel time


plotdata <- lmdata
plotdata$t <- ifelse(abs(plotdata$edd_time_cost_pred/plotdata$edd_time_cost_pred_se)>2&abs(plotdata$inc_time_cost_pred/plotdata$inc_time_cost_pred_se)>2, "both significant", "both insignificant")
plotdata$t <- ifelse(abs(plotdata$edd_time_cost_pred/plotdata$edd_time_cost_pred_se)>2&abs(plotdata$inc_time_cost_pred/plotdata$inc_time_cost_pred_se)<=2, "race significant", plotdata$t)
plotdata$t <- ifelse(abs(plotdata$edd_time_cost_pred/plotdata$edd_time_cost_pred_se)<=2&abs(plotdata$inc_time_cost_pred/plotdata$inc_time_cost_pred_se)>2, "income significant", plotdata$t)
table(plotdata$t)
plotdata$t <- factor(plotdata$t, level = c("both significant", "income significant", "race significant", "both insignificant"))

# calculate confidence box
plotdata$edd_time_cost_pred_min <- plotdata$edd_time_cost_pred - 1.96*plotdata$edd_time_cost_pred_se
plotdata$edd_time_cost_pred_max <- plotdata$edd_time_cost_pred + 1.96*plotdata$edd_time_cost_pred_se
plotdata$inc_time_cost_pred_min <- plotdata$inc_time_cost_pred - 1.96*plotdata$inc_time_cost_pred_se
plotdata$inc_time_cost_pred_max <- plotdata$inc_time_cost_pred + 1.96*plotdata$inc_time_cost_pred_se

plotdata$edd_v_inc_right <- plotdata$edd_time_cost_pred_min > plotdata$inc_time_cost_pred_max
table(plotdata$edd_v_inc_right)

plotdata$edd_v_inc_left <- plotdata$inc_time_cost_pred_min > plotdata$edd_time_cost_pred_max
table(plotdata$edd_v_inc_left, plotdata$edd_v_inc_right)

plotdata$edd_v_inc <- ifelse(plotdata$edd_v_inc_right, "(1) Higher cross-race time eqv.  \n (N=147)", "(3) No significant difference \n (N=341)")
plotdata$edd_v_inc <- ifelse(plotdata$edd_v_inc_left, "(2) Higher cross-income time eqv. \n (N=10)", plotdata$edd_v_inc )

plot_eqv_time_predict <- ggplot(plotdata) +
  geom_vline(xintercept = 0, alpha = .25) +
  geom_hline(yintercept = 0, alpha = .25) +
  geom_abline(slope = 1, alpha = .5) +
  geom_point(data = plotdata, aes(x = edd_time_cost_pred, y = inc_time_cost_pred, color = cut(coef_time, c(-.5, -.15, -.1, 0)), shape = t),  alpha = .75) +
  labs(x= "cross-race time-equivalent (predicted)", y = "cross-income time-equivalent (predicted)", size = "pop (million)", shape = "time eqv. > 0", color = "travel time coef", fill = "travel time coef") +
  geom_text_repel(data = plotdata[poptot > 50000],aes(x = edd_time_cost_pred, y = inc_time_cost_pred+.075, label = PLACENAME), size = 3) +
  geom_text_repel(data = plotdata[poptot > 2000000],aes(x = edd_time_cost_pred, y = inc_time_cost_pred+.075, label = PLACENAME), size = 3) +
  theme_classic() +
  facet_wrap(~edd_v_inc)+
  scale_shape_manual(values = c(19, 10, 13, 1)) 

# Figure 3 
plot_eqv_time_predict
# ggsave("eqv_time_pred_updated_2026.png", width = 9, height = 4)


# plot the three compenents as bar
hist(lmdata$total_time_cost_pred/lmdata$time_cost_av, breaks = 100) # increased 30% of travel time
hist(lmdata$edd_time_cost_pred/lmdata$time_cost_av) # increased 18% of travel time
summary(lmdata$inc_time_cost_pred/lmdata$time_cost_av) # increased 11% of travel time

lmdata <- lmdata %>% arrange(-time_cost_av)
lmdata$PLACENAME <- factor(lmdata$PLACENAME, levels = rev(lmdata$PLACENAME))
lmdata$group <- floor(0:497/84)
table(lmdata$group)
lmdata$group <- factor(lmdata$group, labels = c("Panel 1", "Panel 2", "Panel 3", "Panel 4", "Panel 5", "Panel 6"))


plot_comp_1 <- ggplot(lmdata[group %in% c("Panel 1", "Panel 2", "Panel 3")]) + 
  geom_bar(aes(x = time_cost_av + edd_time_cost_pred + inc_time_cost_pred, y = PLACENAME, fill = "income barrier"), 
           stat="identity") + 
  geom_bar(aes(x = time_cost_av + edd_time_cost_pred, y = PLACENAME, fill = "race barrier"), 
                          stat="identity") + 
  geom_bar(aes(x = time_cost_av , y = PLACENAME, fill = "travel time"), 
           stat="identity") +
  facet_wrap(~group, nrow = 1, scales = "free_y") +
  labs(y = "", x = "minute", fill = "") +
  theme_minimal()

# Figure S4-1
plot_comp_1
# ggsave("eqv_time_pred_rank_1.png", width = 10, height = 12)

plot_comp_2 <-ggplot(lmdata[!group %in% c("Panel 1", "Panel 2", "Panel 3")]) + 
  geom_bar(aes(x = time_cost_av + edd_time_cost_pred + inc_time_cost_pred, y = PLACENAME, fill = "income barrier"), 
           stat="identity") + 
  geom_bar(aes(x = time_cost_av + edd_time_cost_pred, y = PLACENAME, fill = "race barrier"), 
           stat="identity") + 
  geom_bar(aes(x = time_cost_av , y = PLACENAME, fill = "travel time"), 
           stat="identity") +
  facet_wrap(~group, nrow = 1, scales = "free_y") +
  labs(y = "", x = "minute", fill = "") +
  theme_minimal()

# Figure S4-2
plot_comp_2
# ggsave("eqv_time_pred_rank_2.png", width = 10, height = 12)




