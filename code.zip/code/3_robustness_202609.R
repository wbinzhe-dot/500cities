# robustness checks
library(data.table)
library(ggplot2)
library(fixest)
library(dplyr)
library(ggrepel)
library(patchwork)
library(stringr)
library(ggrepel)
options(scipen=1000000)



# log(time +1)
ct_local_jt <- fread('replication_folder/modelling_data/coef_500cities_202609_logtime.csv')
names(ct_local_jt)

hist_logtime_eddtime_ratio <- ggplot(ct_local_jt) +
  geom_histogram(aes(x = edd_time_ratio), alpha = 0.5, binwidth = .25) +
  geom_vline(xintercept = mean(ct_local_jt$edd_time_ratio)) +
  geom_label(data = ct_local_jt[1], aes(x = mean(ct_local_jt$edd_time_ratio)+ 3, label = paste0("mean = 0.76") , y = 5), alpha = 0, label.size = 0) +
  geom_vline(xintercept = median(ct_local_jt$edd_time_ratio), linetype = "dashed") +
  geom_label(data = ct_local_jt[1], aes(x = median(ct_local_jt$edd_time_ratio)+ 3, label = paste0("median = 0.66"), y = 12), alpha = 0, label.size = 0) +
  labs(y = "frequency", x = "coef. of racial distance/coef. log(time + 1)") +
  # lims(x = c(-2, 0.5)) + 
  theme_classic()

hist_logtime_inctime_ratio <- ggplot(ct_local_jt) +
  geom_histogram(aes(x = inc_time_ratio), alpha = 0.5, binwidth = .25) +
  geom_vline(xintercept = mean(ct_local_jt$inc_time_ratio)) +
  geom_label(data = ct_local_jt[1], aes(x = mean(ct_local_jt$inc_time_ratio)+ 2, label = paste0("mean = 0.24") , y = 10), alpha = 0, label.size = 0) +
  geom_vline(xintercept = median(ct_local_jt$inc_time_ratio), linetype = "dashed") +
  geom_label(data = ct_local_jt[1], aes(x = median(ct_local_jt$inc_time_ratio)+ 2, label = paste0("median = 0.22"), y = 21), alpha = 0, label.size = 0) +
  labs(y = "frequency", x = "coef. of income distance/coef. log(time + 1)") +
  # lims(x = c(-2, 0.5)) + 
  theme_classic()

# Figure S5a
hist_logtime_eddtime_ratio|hist_logtime_inctime_ratio
# ggsave("robustness_histgrams_ratio_logtime.png", width = 8, height = 3)



# as minutes
summary(log(ct_local_jt$time_cost_av + 1))
exp(2.347 + 0.76) - exp(2.347) # 11.9 minutes


summary(log(ct_local_jt$time_cost_av + 1))
exp(2.347 + 0.24) - exp(2.347) # 2.8 minutes


# sqrt(time +1)
ct_local_jt <- fread('replication_folder/modelling_data/coef_500cities_241030_sqrttime.csv')
names(ct_local_jt)

hist_logtime_eddtime_ratio <- ggplot(ct_local_jt) +
  geom_histogram(aes(x = edd_time_ratio), alpha = 0.5, binwidth = .5) +
  geom_vline(xintercept = mean(ct_local_jt$edd_time_ratio)) +
  geom_label(data = ct_local_jt[1], aes(x = mean(ct_local_jt$edd_time_ratio)+ 3, label = paste0("mean = 1.27") , y = 5), alpha = 0, label.size = 0) +
  geom_vline(xintercept = median(ct_local_jt$edd_time_ratio), linetype = "dashed") +
  geom_label(data = ct_local_jt[1], aes(x = median(ct_local_jt$edd_time_ratio)+ 3, label = paste0("median = 1.14"), y = 12), alpha = 0, label.size = 0) +
  labs(y = "frequency", x = "coef. of racial distance/coef. sqrt(time)") +
  # lims(x = c(-2, 0.5)) + 
  theme_classic()

hist_logtime_inctime_ratio <- ggplot(ct_local_jt) +
  geom_histogram(aes(x = inc_time_ratio), alpha = 0.5, binwidth = .5) +
  geom_vline(xintercept = mean(ct_local_jt$inc_time_ratio)) +
  geom_label(data = ct_local_jt[1], aes(x = mean(ct_local_jt$inc_time_ratio)+ 2, label = paste0("mean = 0.46") , y = 10), alpha = 0, label.size = 0) +
  geom_vline(xintercept = median(ct_local_jt$inc_time_ratio), linetype = "dashed") +
  geom_label(data = ct_local_jt[1], aes(x = median(ct_local_jt$inc_time_ratio)+ 2, label = paste0("median = 0.45"), y = 20), alpha = 0, label.size = 0) +
  labs(y = "frequency", x = "coef. of income distance/coef. sqrt(time)") +
  # lims(x = c(-2, 0.5)) + 
  theme_classic()

# Figure S5b
hist_logtime_eddtime_ratio|hist_logtime_inctime_ratio
# ggsave("robustness_histgrams_ratio_sqrttime.png", width = 8, height = 3)


summary(sqrt(ct_local_jt$time_cost_av + 1))
(3.268 + 1.27)^2 - (3.268)^2 # 9 minutes
(3.268 + 0.46)^2 - (3.268)^2 # 3 minutes
